//
//  ViewController.swift
//  MyApp
//
//  Created by Trung on 01/10/2022.
//

import UIKit

class MainViewController: UITableViewController {

    var monsters = [Monster]()

    override func viewDidLoad() {
        super.viewDidLoad()
        loadAllMonster { monsters in
            self.monsters = monsters
            print("-- Total monster: \(monsters.count)")
        }
    }
}
