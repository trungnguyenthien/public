//
//  ViewController.swift
//  MyApp
//
//  Created by Trung on 01/10/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        loadAllMonster { monsters in
            print("-- Total monster: \(monsters.count)")
        }
    }
}


